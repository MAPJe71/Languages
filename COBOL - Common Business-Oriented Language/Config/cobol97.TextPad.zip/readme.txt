This unabridged syntax file was made by combining six other files from different versions of COBOL and then eliminating anything that was not recognized as a reserve word by the Fujitsu COBOL-97 compiler.

The conventions for the Keyword Layout is as follows:

	Keywords 1 = divisions and sections
	Keywords 2 = division and section reserved words
	Keywords 3 = procedure division verbs & non-compiler-highlighted intrinsic function names
	Keywords 4 = flow control verbs
	Keywords 5 = recognized intrinsic function names & other unsorted COBOL rerserve words
	Keywords 6 = hyphen ignoring non-keywords (treat as text for colors)


Keywords 6 is a special class of keywords that I designed by taking each reserved word from the other Keywords groups and making a copy that is preceded by a hyphen, followed by a hyphen and enclosed between two hyphens.  When setting up you colors for Keywords 6, make sure that you set them to the same color scheme as you would set your plain text.  By doing this, an implementers that contains a reserved word(s) (like "INPUT-RECORD") will appear as plain text instead of highlighted colored text while the reserved words by themselves will still be highlighted.

R. A. Fiol