import java.net.*;
import java.io.*;

public class java_client
{
   public static void main(String h[])
   {
       try 
       {
          System.out.println("Client Starting...");
          Socket s=new Socket("localhost", 1800);
          PrintWriter wr=new PrintWriter(new OutputStreamWriter(s.getOutputStream()),true);
          wr.println("Hello Server");
          BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
          System.out.println(br.readLine());
      } 
      catch(Exception e) 
      {
         e.printStackTrace();
      }
   }
}
