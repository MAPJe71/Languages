This is part of the project NppX3D, that consists in:

"Open source set for Notepad++ to code in X3D (classic encoding, x3dv)

and VRML, the open standards for interactive and immersive 3D on

Internet.

Includes: set of language files, auto-completion files, tutorials and

instructions and other materials."


It's sourceforge page is https://sourceforge.net/projects/nppx3d/


---------------------------------------------------------

You can contact the developer of NppX3D at:

Jordi R. Cardona

Stay tuned for the upcoming X3D course at Hiperia3D News

Web: Hiperia3D News: http://news.hiperia3d.com/

e-mail: info@hiperia3d.com

SourceForge project: https://sourceforge.net/projects/nppx3d/

