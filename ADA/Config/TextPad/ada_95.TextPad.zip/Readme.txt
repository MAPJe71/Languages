
Ada95 syntax highlighting with some more colors

1- Copy the file 'ada.syn' into the directory 'Samples' of TextPad.

2- Import the file 'TextPad_Ada95_Colors.reg' into the registry. This will create a new TextPad document class 'Ada95colored'.


Bernd Ragutt
b@ragutt.de

