NSIS Example Application 1   by Rizwan Sattar
--------------------------

This is an example script which shows how to install a java program and make it runnable from the start menu.

It can also be uninstalled from the Control Panel or from the Start Menu program group.


Please read the script to see how the installer application was made.

For educational purposes, the script that was used to create this installer is also "installed" (i.e., copied) to the installation directory.

Normally, the script itself would not be included in the actual installation (it is only used to create the installer; typical applications do not include the script into the install directory)