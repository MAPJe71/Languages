# Gradient Experiments

## Installation

### Manual Installation

Copy all `.bmp` files to `%PROGRAMFILES%\NSIS\Contrib\Graphics\Wizard`

## License

![CC SA](http://i.creativecommons.org/l/by-sa/4.0/88x31.png)

This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 Unported License][2].

[1]: http://nsis.sourceforge.net
[2]: http://creativecommons.org/licenses/by-sa/4.0/deed